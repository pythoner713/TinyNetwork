#include<bits/stdc++.h>
using namespace std;

int n = 65, m = 38;
int a[100][100];
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
string all[20] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "cpar", "div", "minus", "opar", "plus", "times"};

int main(){
	for(int fuck = 0; fuck <= 15; fuck++){
		freopen((all[fuck] + ".txt").c_str(), "r", stdin);
		freopen((all[fuck] + ".shit").c_str(), "w", stdout);
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				scanf("%1d", &a[i][j]);
			}
		}
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				int cnt = 0;
				if(!a[i][j]) continue;
				for(int k = 0; k < 4; k++){
					cnt += (bool)a[i + dx[k]][j + dy[k]];
				}
				a[i][j] += (cnt < 4);
			}
		}
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				printf("%d", a[i][j]);
			}
			putchar('\n');
		}
	}
	
	return 0;
}
