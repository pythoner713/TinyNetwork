#include<bits/stdc++.h>
using namespace std;

int a[100][100], d = 6;
string all[20] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "cpar", "div", "minus", "opar", "plus", "times"};

double trans(int x, int y){
	int cnt = 0;
	for(int i = x; i < x + d; i++){
		for(int j = y; j < y + d; j++){
			cnt += a[i][j];
		}
	}
	return (double)cnt / d / d;
}

int main(){
	//std::ios::sync_with_stdio(0);
//	for(int fuck = 0; fuck <= 15; fuck++){
//		string file = "Courier_Prime_" + all[fuck] + ".txt";
//		freopen(file.c_str(), "r", stdin);
//		freopen((all[fuck] + ".txt").c_str(), "w", stdout);
//		
//		int n, m, a[100][100];
//		cin >> m >> n;
//		for(int i = 1; i <= n; i++){
//			string s;
//			cin >> s;
//			for(int j = 1; j <= m; j++){
//				a[i][j] = s[j - 1] == '#';
//			}
//		}
//		
//		int up, down;
//		for(int i = 1; i <= n; i++){
//			for(int j = 1; j <= m; j++){
//				if(a[i][j]){
//					up = i;
//					break;
//				}
//			}
//		}
//		
//		for(int i = n; i; i--){
//			for(int j = 1; j <= m; j++){
//				if(a[i][j]){
//					down = i;
//					break;
//				}
//			}
//		}
//		
//		swap(up, down);
//		int dx = (n - down + up) / 2;
//		for(int i = 1; i <= dx; i++){
//			for(int j = 1; j <= m; j++){
//				cout << "0";
//			}
//			cout << endl;
//		}
//		for(int i = up; i <= down; i++){
//			for(int j = 1; j <= m; j++){
//				cout << a[i][j];
//			}
//			cout << endl;
//		}
//		for(int i = 1; i <= dx; i++){
//			for(int j = 1; j <= m; j++){
//				cout << "0";
//			}
//			cout << endl;
//		}
//	}
	
	freopen("analyse.shit", "w", stdout);
	
	printf("d[20][100][100] = {\n\n");
	for(int fuck = 0; fuck <= 15; fuck++){
		int n = 65, m = 38; // d * d
		freopen((all[fuck] + ".txt").c_str(), "r", stdin);
		
		memset(a, 0, sizeof(a));
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++){
				scanf("%1d", &a[i][j]);
			}
		}
		
		printf("{");
		for(int i = 0; i <= n / d; i++){
			printf("{");
			for(int j = 0; j <= m / d; j++){
				int x = i * d + 1, y = j * d + 1;
				if(j < m / d) printf("%.5f, ", trans(x, y));
				else{
					if(i < n / d) printf("%.5f},\n", trans(x, y));
					else printf("%.5f}},\n\n", trans(x, y));
				}
			}
		}
	}
	return 0;
}
