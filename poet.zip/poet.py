import numpy as np
from math import ceil
from collections import Counter
from random import shuffle, choice

import tensorflow.python.keras as keras
from tensorflow.python.keras.callbacks import LambdaCallback,ModelCheckpoint
from tensorflow.python.keras.models import Input, Model, Sequential
from tensorflow.python.keras.layers import Dropout, Dense, SimpleRNN, LSTM
from tensorflow.python.keras.layers.normalization import BatchNormalization
from tensorflow.keras.optimizers import *
from tensorflow.keras.utils import plot_model

PATH = 'poetry.txt'
file = open(PATH, 'r', encoding = 'utf-8')
BAN_CHARS = ['（', '）', '(', ')', '__', '《', '》', '【', '】', '[', ']']
WORD_NUM = 3000
TRAIN_NUM = 6

poems = []
words = []
train_X = []
train_Y = []

def init():
    for line in file:
        poem = line.split(':')[1]
        poem = poem.replace(' ', '')
        if any([(char in poem) for char in BAN_CHARS]): continue
        if len(poem) < 12 or poem[5] != '，' or (len(poem) - 1) % 6: continue
        for word in poem: words.append(word)
        poems.append(poem)
    counter = Counter(words)
    counter = sorted(counter.items(), key = lambda x: x[1], reverse = 1)
    global vocabulary, word_to_id, id_to_word
    vocabulary, _ = zip(*counter)
    vocabulary = vocabulary[:WORD_NUM - 1] + (' ', )
    word_to_id = {b: a for a, b in enumerate(vocabulary)}
    id_to_word = {a: b for a, b in enumerate(vocabulary)}
    shuffle(poems)
    for poem in poems:
        for i in range(len(poem)):
            X = poem[i: i + TRAIN_NUM]
            Y = poem[i + TRAIN_NUM]
            if Y != '\n':
                train_X.append(X)
                train_Y.append(Y)
            else: break
    
def word_to_one_hot(word):
    result = np.zeros(WORD_NUM)
    if word not in word_to_id: word = ' '
    result[word_to_id[word]] = 1
    return result

def phrase_to_one_hot(phrase):
    return [word_to_one_hot(word) for word in phrase]

def build_model():
    model = Sequential()
    model.add(SimpleRNN(512, return_sequences = True, input_shape = (TRAIN_NUM, WORD_NUM)))
    model.add(SimpleRNN(256))
    model.add(Dense(WORD_NUM, activation = 'softmax'))
    optimizer = SGD(learning_rate = 0.0005)
    model.compile(loss = 'categorical_crossentropy', optimizer = optimizer, metrics = ['accuracy'])
    model.summary()
#   plot_model(model, to_file = 'model.png',
#             show_shapes = True, expand_nested = True, dpi = 200)
    return model

def get_batch(size):
    steps = ceil(len(train_X) / size)
    while True:
        for i in range(steps):
            batch_train_X = []
            batch_train_Y = []
            for i in range(i * size, (i + 1) * size + 1):
                batch_train_X.append(phrase_to_one_hot(train_X[i]))
                batch_train_Y.append(word_to_one_hot(train_Y[i]))
            yield np.array(batch_train_X), np.array(batch_train_Y)

def predict_next_word(X):
    Y = model.predict(X)[0]
    res = np.argmax(Y)
    while id_to_word[res] == ' ':
        Y[res] = 0
        res = np.argmax(Y)
    return res

def write_a_poem(epoch, logs, poem = '#', line = 4):
    if poem == '#':
        poem = choice(poems)
        poem = poem[:TRAIN_NUM]
    while len(poem) < 6 * line:
        X = np.array(phrase_to_one_hot(poem[-6:])).reshape(1, TRAIN_NUM, WORD_NUM)
        Y = predict_next_word(X)
        poem += id_to_word[Y]
    print(poem)

def train():
    size = 128
    model.fit_generator(
        generator = get_batch(size),
        verbose = True,
        steps_per_epoch = ceil(len(train_X) / size / 10),
        epochs = 100,
        callbacks = [
            ModelCheckpoint('PoetCheckpoint.hdf5', verbose = 1, monitor = 'val_loss', period = 1),
            LambdaCallback(on_epoch_end = write_a_poem)
        ]
    )

if __name__ == '__main__':
    init()
    model = build_model()
    model.load_weights('PoetCheckpoint.hdf5')
    #train()
    write_a_poem(0, 0)
    
    
